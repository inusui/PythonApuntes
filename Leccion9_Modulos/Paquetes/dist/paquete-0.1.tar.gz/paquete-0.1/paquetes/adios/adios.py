# Este es un modulo con funciones.
def despedirse():
    print("taluego adios.py")

class Adios():
    def __init__(self):
        print("hasta la proxima desde el __init__ Adios()")