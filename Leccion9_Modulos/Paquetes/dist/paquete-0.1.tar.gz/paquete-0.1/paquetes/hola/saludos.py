# Este es un modulo con funciones.
def saludar():
    print("Holanda desde saludos.py")

class Saludo():
    def __init__(self):
        print("Holanda desde una clase desde saludos")