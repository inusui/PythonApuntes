#informacion sobre este paquete
from setuptools import setup

setup (
    name="paquete",
    version= "0.1",
    description="Paquete de testeo",
    author="SoyInusui",
    author_email="inusui@protonmail.com",
    url="https://mypage.com",
    scripts=[],
    packages=['paquetes', 'paquetes.adios', 'paquetes.hola']
)

